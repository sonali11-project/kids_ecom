<?php

class Account_model extends CI_Model {
   

   public function getData(){
     
      if($this->session->userdata('user_id')) {
      $this->db->select('*');
      $this->db->from('delivered_order');
      $this->db->where('user_id',$this->session->userdata('user_id'));
      $query=$this->db->get()->result_array();
      
      return $query;
     
   }
   }

   public function getUserDetail($id){
   	$this->db->select("*");
   	$this->db->from('users');
   	$this->db->where('id',$id);
   	return $this->db->get()->result_array();
   }

// public function  user_address(){


    
//   }


}