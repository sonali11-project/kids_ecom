<?php
defined('BASEPATH') OR exit('No direct script accesss allowed');

class Cart extends CI_Controller
{
    
    function __construct()
    {
        parent::__construct();
        
        //load cart library 
        $this->load->library('cart');
        $this->load->library('paypal_lib');
        
        //load home model
        $this->load->model('Home_model');
    }
    
    function index()
    {
        $data = array();        
        //retrieve cart data from the session 
        //retrieve cart data from the session 
        $data['cartItems'] = $this->cart->contents();
        //load the cart view
        $this->load->view('common/header');
        $this->load->view('cart', $data);
        $this->load->view('common/footer');
        
        
    }
    
    function updateItemQty()
    {
        $update = 0;
        
        //get cart item info
        $rowid = $this->input->get('rowid');
        $qty   = $this->input->get('qty');
        
        //update item in the cart
        if (!empty($rowid) && !empty($qty)) {
            $data = array(
                'rowid' => $rowid,
                'qty' => $qty
            );
            
            $update = $this->cart->update($data);
        }
        
        //return response
        echo $update ? 'ok' : 'err';
    }
    
    function removeItem($rowid)
    {
        
        //remove item from cart
        $remove = $this->cart->remove($rowid);
        
        //redirect to cart page
        redirect('cart');
    }
    
   
    
}
?>