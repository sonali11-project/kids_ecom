<?php

class CCavenue extends CI_Controller{


	function __construct()
	{
		parent::__construct();
		$this->load->helper("url");	
		$this->load->helper('string');			
		$this->load->model("admin/areas_model");
		$this->load->model("admin/order_model");
		
		$this->load->library('session');
	}

      public function sendRequest()
   {

   $this->load->view("ccavenueform_view");


   }
   
  
}
?>
