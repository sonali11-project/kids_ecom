<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Products extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->library('cart');
    $this->load->model('Category_model');
    $this->load->model('Home_model');
    $this->load->model('product');
    $this->load->model("Search_model");
    $this->load->library('paypal_lib');
    $this->session->set_userdata(array("userid"=>3));
  }
  // Update rating
  public function updateRating(){
    $userid = $this->session->userdata('userid');
    $postid = $this->input->post('postid');
    $rating = $this->input->post('rating');
    $averageRating = $this->product->userRating($userid,$postid,$rating);
    echo $averageRating;
  }
  public function searchBycategory(){
    $id =  $this->uri->segment(3);
    $data['all_products'] = $this->Category_model->getProductByCategory($id);
    $data['Categories'] = $this->Category_model->getCategory();
    $data['arrival_products'] = $this->Home_model->getNreArrival();
    $data['Stores'] = $this->product->getStoreValue();
    $data['attribute_value'] = $this->Home_model->getAttributeValue();
    $this->load->view('common/header');
    $this->load->view('allproducts', $data); 
    $this->load->view('common/footer');
  }
  public function rating_filter(){
    $id=$this->uri->segment(3);
    $this->db->select('products.*,product_review.*');
    $this->db->from('products');
    $this->db->join('product_review', 'product_review.product_id = products.product_id');
    $query = $this->db->where(array('product_review.rating'=>$id));
    $result = $query->get()->result_array();
    $data['products'] = $result;
    $data['Categories'] = $this->Category_model->getCatogory();
    $this->load->view('common/header');
    $this->load->view('allproducts',$data);
    $this->load->view('common/footer');
  }
        
  public function product_review(){
    $data=$this->input->post();
    if(!empty($this->session->userdata('user_id'))){
    if($this->product->review($data)){
      echo 'Review Addedd';
    }else {
      echo 'Review Updated';
    }
    }
    else {
      echo 'Login first for review';
    }
  }
  public function Single_Product($id){
    $data = array();
    $data['s_products'] = $this->Home_model->getProductDetail($id);
    $data['arrival_products'] = $this->Home_model->getNreArrival();
    $data['reviews'] =  $this->product->getReviews($id);
    $this->load->view('common/header');
    $this->load->view('single_product', $data);
    $this->load->view('common/footer');
  }
  /*  Show All prodcuts*/
  public function allProducts() {
    if(!empty($this->input->get('s')) && !empty($this->input->get('e'))){
      $starting = $this->input->get('s');
      $ending = $this->input->get('e');
      $data = array();
      $data['all_products'] = $this->Home_model->getAllProducts($starting,$ending);
      $data['arrival_products'] = $this->Home_model->getNreArrival();

      $data['Categories'] = $this->Category_model->getCategory();
      $data['Stores'] = $this->product->getStoreValue();
      $this->load->view('common/header');
      $this->load->view('allproducts' , $data);
      $this->load->view('common/footer');
    }else {
      $data = array();
      $data['all_products'] = $this->Home_model->getAllProducts();
      $data['Categories'] = $this->Category_model->getCategory();
      $data['arrival_products'] = $this->Home_model->getNreArrival();
      $data['attribute_value'] = $this->Home_model->getAttributeValue();
      $data['Stores'] = $this->product->getStoreValue();

      $this->load->view('common/header');
      $this->load->view('allproducts' , $data);
      $this->load->view('common/footer');
      }
    }

    /* single product quanity update */
  public function updateItemQty() {
    $update = 0;        
    $rowid = $this->input->get('rowid');
    $qty   = $this->input->get('qty');
    if (!empty($rowid) && !empty($qty)) {
      $data = array(
        'rowid' => $rowid,
        'qty' => $qty
      );
    $update = $this->cart->update($data);
    }
    echo $update ? 'ok' : 'err';
  }
    
    /*Search filter */
  public function skeyword() {
    $key = $this->input->post('title');
    $data['products'] = $this->Search_model->search($key);
    $data['Categories'] = $this->Category_model->getCategory();
    $data['attribute_value'] = $this->Home_model->getAttributeValue();
    $data['Stores']=$this->product->getStoreValue();
    
    $this->load->view('common/header');
    $this->load->view('skeyview', $data);
    $this->load->view('common/footer');

  }

    /* sorting high low product*/
  public function sorting(){
    $value=$this->uri->segment(3);
    if($value==1){
      $data['all_products']= $this->product->sortings($value);
      $data['Stores']=$this->product->getStoreValue();
      $data['attribute_value'] = $this->Home_model->getAttributeValue();
      $data['Categories'] = $this->product->getCatogory();
      $this->load->view('common/header');
      $this->load->view('allproducts',$data);
      $this->load->view('common/footer');
    }else {
      $data['Stores']=$this->product->getStoreValue();
      $data['Categories'] = $this->product->getCatogory();
      $data['all_products']= $this->product->sortings($value);
      $data['attribute_value'] = $this->Home_model->getAttributeValue();

      $this->load->view('common/header');
      $this->load->view('allproducts',$data);
      $this->load->view('common/footer');
    }

    }

    /* size product*/
    public function productsize(){
    
      $value=$this->uri->segment(3);
      $data['all_products']= $this->product->productsizing($value);
      $data['Stores']=$this->product->getStoreValue();
      $data['attribute_value'] = $this->Home_model->getAttributeValue();


      //$data['products']=$this->product->sortings($value);
      $data['Categories'] = $this->product->getCatogory();
      $this->load->view('common/header');
      $this->load->view('allproducts',$data);
      $this->load->view('common/footer');
    }

    public function productstore() {
      $value=$this->uri->segment(3);
      $data['all_products']= $this->product->productsizing($value);         
      $data['Stores']= $this->product->getStoreValue();
      $data['Categories'] = $this->product->getCatogory();
      $data['attribute_value'] = $this->Home_model->getAttributeValue();

      $this->load->view('common/header');
      $this->load->view('allproducts',$data);
      $this->load->view('common/footer');
    }

  public function fetch(){
    echo $this->product->html_output();
  }

  public function insert(){
    if($this->input->post('business_id')){
     $data = array(
      'business_id'  => $this->input->post('business_id'),
      'rating'   => $this->input->post('index')
     );
     $this->product->insert_rating($data);
    }
  }
}
?>