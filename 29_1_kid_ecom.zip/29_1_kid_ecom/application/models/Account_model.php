<?php

class Account_model extends CI_Model {
   

   public function getData(){
     
      if($this->session->userdata('user_id')) {
      $this->db->select('products.*');
      $this->db->from('orders');
      $this->db->join('orders_item','orders_item.order_id = orders.id');
      $this->db->join('products','orders_item.product_id=products.id');
      $this->db->where('user_id',$this->session->userdata('user_id'));
      $query=$this->db->get()->result_array();
      // echo '<pre>';
      // print_r($query);exit;
      
      return $query;
     
   }
   }

   public function getUserDetail($id){
   	$this->db->select("*");
   	$this->db->from('users');
   	$this->db->where('id',$id);
   	return $this->db->get()->result_array();
   }

// public function  user_address(){


    
//   }


}