<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Category_model extends CI_Model
{
    
    function __construct()
    {
        // $this->proTable      = 'categories';
        $this->proTable      = 'products';
        $this->catTable      = 'categories';
        $this->custTable     = 'customers';
        $this->ordTable      = 'orders';
        $this->ordItemsTable = 'order_items';
     
        
    }
    
    public function getCategory($id = '')
    {
        $this->db->select('*');
        $this->db->from($this->catTable);
        
        if ($id) {
            $this->db->where('id', $id);
            $query  = $this->db->get();
            $result = $query->result_array();
        } else {
            $this->db->order_by('id', 'asc');
            $query  = $this->db->get();
            $result = $query->result_array();
        }
        
        //return fetched data
        return !empty($result) ? $result : false;
    }
    public function getProductByCategory($id = ''){
        $this->db->select('*');
        $this->db->from($this->proTable);
        $this->db->where('status', '1');
        if ($id) {
            $this->db->like('category_id', $id);
            $query  = $this->db->get();
            $result = $query->result_array();
        } else {
            $this->db->order_by('name', 'asc');
            $query  = $this->db->get();
            $result = $query->result_array();
        }
        //echo $this->db->last_query();die;    
        //return fetched data
        return !empty($result) ? $result : false;
    }

 
    
}

?>