<?php 

 /**
  * 
  */
 class Search_model extends CI_Model
 {
 	
 	function __construct()
 	{
 		parent::__construct();
 		$this->load->database();
 	}


 	public function search($key){
 		$this->db->like('name' , $key);
 		$query = $this->db->get('products');
 		return $query->result();
 	}
 }
?>