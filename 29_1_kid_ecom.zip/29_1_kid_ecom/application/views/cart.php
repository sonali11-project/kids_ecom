<?php  $admin_url = $this->config->item('admin_url'); ?>
<div class="item active inner_pages">
   <img src="<?php echo base_url('assets/img/cart.jpg');?>" alt=" ">                      
   <div class="theme-container container">
      <div class="caption-text">
         <div class="cart_banner">
            <div class="inner_bg">
               <h3>Cart List</h3>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- breadcrumb start-->
<!--================Cart Area =================-->
<section class="cart_area section_padding">
   <div class="container">
   <div class="cart_inner">
      <div class="">
         <div class="row">
            <div class="col-md-12">
               <div class="table-responsive">
                  <table class="table">
                     <thead>
                        <tr>
                           <th scope="col">Product</th>
                           <th scope="col">Price</th>
                           <th scope="col">Quantity</th>
                           <th scope="col">Total</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $this->total_amount=0; ?>
                        <?php if($this->cart->total_items() > 0){ foreach($cartItems as $item){
                                               
                           $this->total_amount = $this->total_amount + $item['subtotal']; 
                                             
                           ?>
                        <tr>
                           <td>
                              <div class="media">
                                 <div class="d-flex">
                                    <img class="card-img rounded-0" src="<?= $admin_url ?><?=  $item['image']; ?>"  alt="">
                                 </div>
                                 <div class="media-body">
                                    <?php echo $item["name"]; ?>
                                 </div>
                              </div>
                           </td>
                           <td><?php echo '<i class="fas fa-rupee-sign"></i>'.$item["price"]; ?></td>
                           
                           <td><input type="number" class="form-control text-center" value="<?php echo $item["qty"]; ?>" onchange="updateCartItem(this, '<?php echo $item["rowid"]; ?>')"></td>
                           <td id="<?= $item['rowid'] ?>"><?= $item['subtotal'] ?></td>
                           <td>
                              <a href="<?php echo base_url('cart/removeItem/'.$item["rowid"]); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a>
                           </td>
                        </tr>
                        <?php } }else{ 
                          ?>
                        <tr>
                           <td colspan="6">
                              <p>Your cart is empty.....</p>
                           </td>
                           <?php } ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-12">
               <div class="cupon_text float-right">
                  <a class="btn_1" href="">Update Cart</a>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-12">
               <div class="cart_subtotal_name">
                  <ul>
                     <li>
                        <h5>Subtotal</h5>
                     </li>
                     <li>
                        <h5 class="text-right"><i class="fas fa-rupee-sign"></i><?= $this->total_amount ?></h5>
                     </li>
                     <li>
                        <h5>Shipping</h5>
                     </li>
                     <li>
                        <h5 class="text-right"><i class="fas fa-rupee-sign"></i>20.00</h5>
                     </li>
                     <li>
                        <h5>Coupon Discount</h5>
                     </li>
                     <li>
                        <?php if(!empty($coupon)) { ?>
                        <h5 class="text-right"><i class="fas fa-rupee-sign"></i><?= $coupon ?></h5>
                        <?php } else { ?>
                        <h5 class="text-right"><i class="fas fa-rupee-sign"></i>00.00</h5>
                        <?php } ?>
                     </li>
                     <li>
                        <h5>Total</h5>
                     </li>
                     <li>
                        <?php if(!empty($coupon)) { ?>
                        <h5 class="text-right"><i class="fas fa-rupee-sign"></i><?= $this->total_amount + 20-$coupon ?></h5>
                        <?php } else {?>
                        <h5 class="text-right"><i class="fas fa-rupee-sign"></i><?= $this->total_amount + 20 ?></h5>
                        <?php } ?>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="checkout_btn_inner float-right">
            <a class="btn_1" href="<?php echo base_url('/')?>">Continue Shopping</a>
            <a class="btn_1 checkout_btn_1" href="<?php echo base_url('checkout'); ?>">Proceed to checkout</a>
         </div>
      </div>
   </div>
</section>
<script>
   / Update item quantity /
   function updateCartItem(obj, rowid){
   $.get("<?php echo base_url('cart/updateItemQty/'); ?>", {rowid:rowid, qty:obj.value}, function(resp){
   if(resp == 'ok'){
   location.reload();
   }else{
   
   }
   });
   }
   
   function d(id){
    //alert(id);
     // alert('decrement');
     var obj1=document.getElementsByClassName(id);
     if(obj1[0].value == 1 ) {
   
     }
     else {
     var obj=document.getElementsByClassName(id);
     obj[0].value=parseInt(obj[0].value)-1;
     
     $.get("<?php echo base_url('cart/updateItemQty/'); ?>", {rowid:id, qty:obj[0].value}, function(resp){
       if(true){
       document.getElementById(id).innerHTML=resp;
       }else{
         alert('Cart update failed, please try again.');
       }
     });
   }
   }
   
   function i(id){
    //alert('decrement');
     var obj=document.getElementsByClassName(id);
     obj[0].value=parseInt(obj[0].value)+1;
   
     $.get("<?php echo base_url('cart/updateItemQty/'); ?>", {rowid:id, qty:obj[0].value}, function(resp){
       if(true){
         document.getElementById(id).innerHTML=resp;
       }else{
         alert('Cart update failed, please try again.');
       }
     });
   
   }
</script>