  <?php  $admin_url = $this->config->item('admin_url'); ?>
     
<?php if(!empty($status)){ ?>
<div class="status <?php echo $status['type']; ?>"><?php echo $status['msg']; ?>
</div>
<?php } ?>

<div class="item active inner_pages">
  <img src="http://15.206.103.57/kids_ecom/assets/img/cart.jpg" alt=" ">                      
  <div class="theme-container container">
    <div class="caption-text">
      <div class="cart_banner">
        <div class="inner_bg">
        <h3>Contact</h3>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container no-padding mt30 contant_content">
   <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
    <div class="col-md-6 col-sm-6 col-xs-12">
        <div class="contact_left">
         <p><i class="fa fa-map-marker" aria-hidden="true"></i><b>N.L. HAMALPURA KAMPTEE, indore  452002</b></p>
         <p><i class="fa fa-phone" aria-hidden="true"></i><b>9898989898 / 9898989898</b></p>
         <p><i class="fa fa-envelope" aria-hidden="true"></i><b>Demo@gmail.com</b></p>
        </div>
      </div>
         <div class="col-md-6">
        <?php  if(!empty($this->session->flashdata('result'))){ ?>
        <div class="alert alert-success"><?= $this->session->flashdata('result') ?></div>
      <?php } ?>
         <div class="page-header contact_right_form" id="top">
            <!-- Contact form -->
            <form class="contact2-form validate-form" name="contact" action="<?= base_url() ?>Contact/submit" method="post">
               <div class="wrap-input2 validate-input">
                  <input class="wrap-input2 validate-input" type="text" name="name" value="<?php echo !empty($postData['name'])?$postData['name']:''; ?>" placeholder="Enter Name" required>
                  <?php echo form_error('name','<p class="field-error">','</p>'); ?>
               </div>
               <div class="wrap-input2 validate-input">
                  <input class="wrap-input2 validate-input" type="email" name="email" value="<?php echo !empty($postData['email'])?$postData['email']:''; ?>" placeholder="Enter Email" required>
                  <?php echo form_error('email','<p class="field-error">','</p>'); ?>
               </div>
              <!--  <div class="wrap-input2 validate-input">
                  <input class="wrap-input2 validate-input" type="number" name="contact_no" min_length="10" max_length="10" pattern="[1-9]{1}[0-9]{9}" value=" <?php echo !empty($postData['contact_no'])?$postData['contact_no']:''; ?>"  placeholder="Enter Number" required>
                  <?php echo form_error('contact_no','<p class="field-error">','</p>'); ?>
               </div> -->
                <div class="wrap-input2 validate-input">
                        <input class="wrap-input2 validate-input" type="text" name="contact_no"   value placeholder="Enter Number" minlength="10" maxlength="10" autocomplete="on" value=" <?php echo !empty($postData['contact_no'])?$postData['contact_no']:''; ?>">
                           <?php echo form_error('contact_no','<p class="field-error">','</p>'); ?>
                      </div>
               <div class="wrap-input2 validate-input textarea_field">
                  <textarea class="wrap-input2 validate-input" name="message" placeholder="Enter Comment" ><?php echo !empty($postData['message'])?$postData['message']:''; ?></textarea>
                  <?php echo form_error('message','<p class="field-error">','</p>'); ?>
               </div>
               <div  class="container-contact2-form-btn">
                  <input class="contact2-form-btn" type="submit" name="contactSubmit"  value="Submit">
               </div>
            </form>
         </div>
      </div>     
   </div>
</div>
<div class="container">
   <div class="row">
       <div class="col-md-12">
        <div class="contact_right">
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14878.733129957507!2d79.17114623712371!3d21.2047370293833!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd4c613846583b5%3A0xce98a6166b08b0b5!2sMaharashtra%20441002!5e0!3m2!1sen!2sin!4v1573907682709!5m2!1sen!2sin"></iframe>
        </div>
      </div>
   </div>
</div>

<script>
$( document ).ready(function() {
  $(function() {  
    $("form[name='contact']").validate({
      // Specify validation rules
      rules: {
        
      mobileNo:{
          required:true,
          minlength:9,
          maxlength:10,
          number: true
        },

      // Specify validation error messages
      messages: {
        
        mobileNo: "Please enter  10 digit mobile number",
        
      submitHandler: function(form) {
        form.submit();
      }
    });
  });
})
</script>