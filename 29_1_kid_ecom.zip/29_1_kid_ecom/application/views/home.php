<?php  $admin_url = $this->config->item('admin_url'); ?>
<!-- Main Slider Start -->
<section id="main-slider" class="carousel slide main-slider style-1 light-bg" >
   <div class="carousel-inner slider">
      <div class="item active">
         <img src="<?php echo base_url('assets/img/small-slide-girls.jpg')?>" alt=" ">                      
         <div class="theme-container container">
            <div class="caption-text">
               <div class="title-wrap">
                  <h2 class="section-title">
                     <span >
                     <span class="funky-font blue-tag">Awesome Gir's </span> 
                     </span>
                  </h2>
               </div>
               <div class="discount-wrap">
                  <h2 class="discount pink-color">School Styles</h2>
               </div>
               <p></p>
               <div class="slider-link">
                  <a class="blue-btn btn" href="<?php echo base_url('Products/allProducts/');?>">Shop Now </a>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- / Main Slider Ends -->   
<!-- Category Start -->

<section id="category" class="space-35">
   <div class="container theme-container">
      <div class="row">
        <?php if(!empty($Categories)){ foreach($Categories as $row){ ?>
         <div class="col-md-3 col-sm-3 category-wrap">
            <div class="pink-borders">
               <div class="category-box">
                <!--   <img src="<?php echo  base_url('assets/img/boys-cat-thumb.jpg');?>"> -->
                    <img src="<?= $admin_url?>assets/images/product_image/<?= $row['image']; ?>"  alt="">
                  <div class="title-wrap">
                     <h3><?php echo $row['name']; ?></h3> 

                     <!-- <h5>Clothing(7)</h5> -->
                  </div>
                  <div class="overlay">
                     <div class="text"><a href="<?php echo base_url('products/searchBycategory/'.$row['id']); ?>">
                        <?php echo $row['name']; ?></a></div>                 
                 </div>
               </div>
            </div>
         </div>
          <?php } } else{ ?>
            <img src="<?php echo  base_url('assets/product_image/noproduct.png')?>">                  <?php } ?>
      </div>
   </div>
</section>
<!-- / Category Ends -->
<section class="sidebar_sec">
   <div  class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="product_head">
               <h1>Product</h1>
               <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs
               </p>
            </div>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <!--sidebar section start  -->
         <div class="col-md-3 col-sm-3 fashion-bg">
            <div class="left_side_bar_home">
               <nav class='animated bounceInDown'>
                  <h2 class="filter-title blue-bg-with-shadow">Categories 
                  </h2>
                  <?php if(!empty($Categories)){ foreach($Categories as $row){ ?>
                   <div class="overlay">
                  <ul>
                     <li><a href="<?php echo base_url('products/searchBycategory/'.$row['id']); ?>">
                        <?php echo $row['name']; ?></a>
                     </li>
                  </ul>
                  <?php } } else{ ?>
            <img src="<?php echo base_url('assets/product_image/noproduct.png')?>">                  <?php } ?>
               </nav>
            </div>
         </div>
         <!-- sidebar ends -->
         <div class="col-md-9 col-sm-9 right_side">
            <?php if(!empty($products)){ foreach($products as $row){ ?>
            <div class="col-md-4 col-sm-6">
               <div class="item">
                  <div class="product-details">
                     <div class="product-media">
                        <img class="card-img rounded-0" src="<?= $admin_url ?><?= $row['image']; ?>"  alt="">
                        <div class="product-overlay">
                           <a class="addcart blue-background fa fa-shopping-cart" href="<?php echo base_url('welcome/addToCart/'.$row['id']); ?>"></a>                                 
                           <a class="likeitem green-background fa fa-heart" href="<?php echo base_url('wishlist/addTowishlist/'.$row['id']); ?>"></a>
                        </div>
                     </div>
                     <div class="product-content">
                        <div class="product-name">
                           <a href="<?php echo base_url('Products/Single_Product/'.$row['id']);?>"><?php echo $row['name']; ?></a>
                        </div>
                        <div class="product-price">
                           <h4 class="pink-btn-small">$<?php echo $row['price']; ?></h4>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <?php } }else{ ?>
               <img src="<?php  echo base_url('assets/product_image/noproduct.png')?>">            <?php } ?>
         </div>
         <div class="col-md-12">
            <div class="shop_now_btn">
               <a href="<?php echo base_url('Products/allProducts/');?>" class="btn btn-default btn-design">
              View More
               </a>
            </div>
         </div>
      </div>
      <!-- / Filter & All Fashion 1 Ends -->
   </div>
</section>
<!-- CONTENT AREA -->
<!-- Product Most Popular Start -->
<section id="product-tabination-1" class="space-bottom-45 new_arrival_bg" style="background: url(./assets/img/new_arrivals.png) no-repeat #efefef;
   background-position: top center;">
   <div class="container theme-container">
      <div class="light-bg product-tabination">
         <div class="col-md-12">
            <div class="new_arrival_heading">
               <h1>New Arrivals</h1>
               <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in
                  laying out print, graphic or web designs   
               </p>
            </div>
         </div>
         <div class="tabination">
            <div class="product-tabs" role="tabpanel">
               <div class="tab-content">
                  <!-- =============================== Most Popular ============================= -->
                  <div id="most-popular" class="tab-pane fade active in" role="tabpanel">
                     <div class="col-md-12 product-wrap default-box-shadow">
                        <?php if(!empty($arrival_products)){ foreach($arrival_products as $row){ ?>
                        <div class="col-md-3 col-sm-6">
                           <div class="item">
                              <div class="product-details">
                                 <div class="product-media">
                                    <!--    <span class="hover-image white-bg">
                                       <img class="card-img rounded-0" src="<?= $admin_url ?>/assets/images/<?=  $row['image']; ?>"  alt="">                                
                                       </span>   -->
                                    <img class="card-img rounded-0" src="<?= $admin_url ?><?= $row['image']; ?>"  alt="">
                                    <div class="product-overlay">
                                       <a class="addcart blue-background fa fa-shopping-cart" href="<?php echo base_url('welcome/addToCart/'.$row['id']); ?>"></a>                                 
                                       <a class="likeitem green-background fa fa-heart" href="<?php echo base_url('wishlist/addTowishlist/'.$row['id']); ?>"></a>
                                    </div>
                                 </div>
                                 <div class="product-content">
                                    
                                    <div class="product-name">
                                       <a href="<?php echo base_url('Products/Single_Product/'.$row['id']);?>"><?php echo $row['name']; ?></a>
                                    </div>
                                    <div class="product-price">
                                       <h4 class="pink-btn-small">$<?php echo $row['price']; ?></h4>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php } }else{ ?>
                  <img src="<?php  echo base_url('assets/product_image/noproduct.png')?>">                        <?php } ?>
                     </div>
                     <div class="col-md-12">
                        <div class="shop_now_btn">
                           <a href="<?php echo base_url('Products/allProducts/');?>" class="btn btn-default btn-design">
                           Shop Now
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- / Product Most Popular Ends -->
<div class="newsletter_bg">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <div class="nwesletter_head">
               <h1>Subcribe to Our Newsletter</h1>
               <p>Lorem ipsum, or lipsum as it is sometimes known,</p>
            </div>
         </div>
         <div class="col-md-6">
            <div class="newsletter_input">
               <form>
                  <input type="text" name="" placeholder="Your Email">
                  <a href="#" class="btn btn-default btn-design">
                  Shop Now
                  </a>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>