
<div class="item active inner_pages">
  <img src="http://15.206.103.57/kids_ecom/assets/img/cart.jpg" alt=" ">                      
  <div class="theme-container container">
    <div class="caption-text">
      <div class="cart_banner">
        <div class="inner_bg">
        <h3>Login</h3>
        </div>
      </div>
    </div>
  </div>
</div>

<!--CSS Spinner-->
<section class="login_page_bg">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-md-offset-4 well">
        <div class="login_register">
        
              <div  class="<?php if(!empty($this->session->flashdata('message')
                     )){ echo 'tab-pane fade in'; } else {echo 'tab-pane fade in active show';} ?>"   id="tablogin">
                <div class="login">
                  <form action="<?= base_url() ?>Login/process" method="post">
                    <?php  if(!empty($login_result) && !empty($class)){  ?>
                    <div class="<?= $class ?>"><?= $login_result ?></div>
                    <?php  } ?>
                    <div class="form-group">
                      <label for="email">Email address:</label>
                      <input type="email" name="user" class="form-control" id="email">
                    </div>
                    <div class="form-group">
                      <label for="pwd">Password:</label>
                      <input type="password" name="pass" class="form-control" id="pwd">
                    </div>
                    <div class="form-group form-check">
                      <label class="form-check-label"><input class="form-check-input" type="checkbox"> Remember me</label>
                    </div>
                    <div class="login_btn">
                      <button type="submit" class="btn btn-primary">Login</button>
                      <p>Don't have an account? 
                       <a href="<?php echo base_url('Login/signUpProcess'); ?>" class="dropdown-toggle">SignUp</a><br>
                      <a href="<?= base_url() ?>login/forget_password" class="forgot_pwd" >Forget Password?</a>
                      </p>
                    </div>
                  </form>                
                </div>
              </div>
        </div>
      </div>
    </div>
  </div>
</section>
