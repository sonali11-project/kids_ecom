<?php  $admin_url = $this->config->item('admin_url'); ?>
<div class="item active inner_pages">
   <img src="assets/img/cart.jpg" alt=" ">
   <div class="theme-container container">
      <div class="caption-text">
         <div class="cart_banner">
            <div class="inner_bg">
               <h3>My Account</h3>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="user_dashboard_bg">
   <div class="container">
 
      <div class="row">
         <div class="col-md-3">
            <div class="panel with-nav-tabs panel-default dashboard_tab">
               <div class="panel-heading">
                  <ul class="nav nav-tabs">
                     <li class="active">
                        <a href="#tabdash1" data-toggle="tab" class="active">
                        Dashboard</a>
                     </li>
                     <li><a href="#tabdash2" data-toggle="tab">Order</a></li>
                     <!-- <li><a href="#tabdash3" data-toggle="tab">Address</a></li> -->
                     <li><a href="#tabdash4" data-toggle="tab">Account Detail</a></li>
                     <li><a href="<?= base_url() ?>Login/logout">Log Out</a> </li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="col-md-9">
            <div class="panel with-nav-tabs panel-default dashboard_tab">
               <div class="panel-body">
                  <div class="tab-content">
                     <div class="tab-pane fade in  active" id="tabdash1">
                        <div class="col-md-12">
                           <div class="profile_detail">
                              <h4>
                                 <?= $user[0]['firstname']. ' '.$user[0]['lastname'] ?> 
                              </h4>
                              <ul>
                                 <li><i class="glyphicon glyphicon-envelope"></i>
                                    <?= $user[0]['email']  ?>
                                 </li>
                                 <li><i class="fa fa-phone"></i>
                                    <?= $user[0]['phone'] ?>
                                 </li>
                              </ul>
                           </div>
                           <!-- Split button -->
                        </div>
                     </div>
                     <!-- tab-pane -->
                     <div class="tab-pane fade" id="tabdash2">
                        <div class="order_list account_order">
                           <div class="span5 table-responsive">
                              <table class="table table-striped table-condensed">
                                 <tbody>
                                 <th>Image</th>
                                 <th>Product Name</th>
                                 <th>Product Amount</th>
                                 
                                    <?php 
                                       if(!empty($product_delivered)){  ?>
                                    <?php foreach($product_delivered as $data ) {
                                       ?>
                                    
                                    <tr>
                                       <td>
                                          <img class="card-img rounded-0" src="<?= $admin_url ?><?= $data['image']; ?>" alt="">
                                       </td>
                                       <td>
                                          <?= $data['name']  ?>
                                       </td>
                                        <td>
                                          <?= $data['price'] ?>
                                        </td>
                                       
                                                             
                                    </tr>
                                   
                                    <?php    } } else  {echo 'not ordered yet';
                                       } ?>
                                      <!--  <tr>
                                        <td>
                                          <div class="row">
                                            <div class="col-sm"
                                          total amount <?= $data['price'] ?>
                                            </div>
                                          </td></tr> -->
                                 </tbody>
                              </table>
                           </div>
                           <div class="order_load_more">
                              <!--  <a href="#" class="btn btn-default">Load More</a> -->
                           </div>
                        </div>
                     </div>
                      <!-- <div class="tab-pane fade" id="tabdash3">

                            <form action="<?= base_url() ?>login/addresses" method="post"> 
                              <div class="custom1" id="address_display">
                                 <?php
                                    if(!empty($this->session->userdata('user_id'))) {
                                    $this->db->select('*');
                                     $this->db->from('delivered_order');
                                     $this->db->where('User_id',$this->session->userdata('user_id'));
                                     $this->address = $this->db->get()->result_array();
                                    ?>
                                <div class="col-md-12"> <h4>Address</h4></div>
                                 <?php if(!empty($this->address)) { 
                                    for($i=0;$i<count($this->address);$i++) {
                                       
                                    ?>
                                    <div class="col-md-6">                                 <address><?= $this->address[$i]['Street'].' '. $this->address[$i]['Address2'].' '.
                                    $this->address[$i]['City'].' '.$this->address[$i]['State'].' '.$this->address[$i]['zipcode']
                                    ?></address>
                                 <!-- <a class="btn btn-primary "  id="<?= $this->address[$i]['id']  ?>" href="<?=  base_url() ?>login/edit/<?= $this->address[$i]['id']  ?>" >Edit</a>
                                 <a class="btn btn-info" name="remove" href="<?= base_url() ?>login/delete/<?= $this->address[$i]['id'] ?>">Remove</a> -->
                                    <!-- </div>

                                 <?php 
                                    }
                                    }
                                    }
                                    ?>
                              </div>
                           </form>

                            <div class="clearfix"></div>  
                             <br />
                             <?php if(!empty($error)) { ?>
                             <div class="col-sm-12"><div class="alert alert-danger">Field is required</div></div>
                          <?php } ?>  -->
                     <?php  if(!empty($status) && !empty($edit)) {  ?>
                           <form action="<?= base_url() ?>login/delivered_order" method="post">
                              <div class="custom1">
                                 <div class="">
                                    <div class="">
                                       <div class="row">
                                          <div class="col-sm-6">
                                             <div class="user_dashboard">
                                                <label>Address 1 * </label>
                                                <input type="text" value="<?= $edit[0]['Address1']  ?>" name="address1">    
                                             </div>
                                          </div>
                                          <br>
                                          <div class="col-sm-6 ">
                                             <div class="user_dashboard">
                                                <label>Address 2 * </label>
                                                <input type="text" value="<?= $edit[0]['Address2']  ?>" name="address2">  
                                             </div>
                                          </div>
                                       </div>
                                       <input type="hidden" name="id"  value="<?= $edit[0]['id'] ?>">
                                       <div class="row">
                                          <div class="col-sm-6">
                                             <div class="user_dashboard">
                                                <label>City * </label><br>
                                                <input type="text" value="<?=  $edit[0]['City'] ?>" name="city">   
                                             </div>
                                          </div>
                                          <div class="col-sm-6">
                                             <div class="user_dashboard">
                                                <label>State * </label><br>
                                                <input type="text" value="<?= $edit[0]['State'] ?>" name="state">       
                                             </div>
                                          </div>
                                       </div>
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="user_dashboard">
                                                <label>Pincode * </label><br>
                                                <input type="text"  value="<?= $edit[0]['Pincode'] ?>" name="pincode">   
                                             </div>
                                          </div>
                                       </div>
                                       <br>
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="user_dashboard">
                                                <Button type="submit" name="save" class="btn btn-primary">Update address</Button> 
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!--  <div class="tab-pane fade" id="tabdash4">
                                    </div> -->
                              </div>
                           </form>
                            <?php } else { ?>
                     <!-- tab-pane -->
                     <div class="tab-pane fade" id="tabdash4">
                        <div class="custom1 account_details_sn">
                           <div class="row">
                              <div class="col-sm-12" id="result">
                              </div>
                              <div class="col-sm-6">
                                 <div class="form-group">
                                    <?php
                                       if(!empty($this->session->userdata('user_id'))) {
                                         // echo $this->session->userdata('user_id');
                                       $this->db->select('*');
                                       $this->db->from('users');
                                       if(!empty($this->session->userdata('user_id'))){
                                        $s = $this->session->userdata('user_id');
                                       }
                                       else {
                                        $s = 0;
                                       }
                                       $this->db->where('id',$s);
                                       $this->address1 = $this->db->get()->result_array();
                                       //print_r($this->address1);
                                       } ?>
                                    <label>First Name</label>
                                    <br>
                                    <input type="text" value="<?= $this->address1[0]['firstname'] ?>" name="firstname" id="firstname" placeholder="First name" class="form-control">
                                 </div>
                              </div>
                              <div class="col-sm-6">
                                 <div class="form-group">
                                    <label>Last Name</label>
                                    <br>
                                    <input type="lastname" id="lastname" value="<?= $this->address1[0]['lastname'] ?>" name="lastname" placeholder="lastname" class="form-control">
                                 </div>
                              </div>
                              <div class="col-sm-6">
                                 <div class="form-group">
                                    <label>Email</label>
                                    <br>
                                    <input type="email" id="user_email" value="<?= $this->address1[0]['email'] ?>" name="email" placeholder="Email" class="form-control">
                                 </div>
                              </div>
                              <div class="col-sm-6">
                                 <div class="form-group">
                                    <label>Phone</label>
                                    <br>
                                    <input type="phone" id="phone" value="<?= $this->address1[0]['phone'] ?>" name="phone" placeholder="Phone" class="form-control">
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-sm-12">
                                 <div class="save_change_btn_detail">
                                    <button id="submit" name="save" class="btn btn-primary">Save Chages</button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- tab-pane -->
                  </div>
                  <!-- tab-content -->
               </div>
               <!-- panel-body -->
            </div>
         </div>
      </div>
   </div>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
<script>
   $(document).ready(function() {
       $('#save_address').click(function() {
           var Address1 = $('#address1').val();
           var Address2 = $('#address2').val();
           var City = $('#city').val();
           var State = $('#state').val();
           var Pincode = $('#pincode').val();
   
           if (Address1 != '' && Address2 != '' && City != '' && State != '' && Pincode != '') {
               var address = {
                   address1: Address1,
                   address2: Address2,
                   city: City,
                   state: State,
                   pincode: Pincode
               }
               $.post("<?= base_url() ?>login/address", address, function(result) {
                   $('#result_address').html('<p class="alert alert-success">' + result + '</p>');
   
               });
   
           } else {
   
               $('#result_address').html('<p class="alert alert-danger">All field is required</p>');
   
           }
   
       })
   
       $('#submit').click(function() {
   
           var firstname = $('#firstname').val();
           var lastname = $("#lastname").val();
           var email = $('#user_email').val();
           var phone = $("#phone").val();
           if (phone != "" && email != "") {
               var update_user = {
                   firstname: firstname,
                   email: email,
                   lastname:lastname,
                   phone:phone
               }
               //console.log(update_user);
   
               $.post("<?= base_url() ?>Login/user_address", update_user, function(result) {
                   $('#result').html('<p class="alert alert-success">' + result + '</p>');
               });
           } else {
               $('#result').html('<p class="alert alert-danger">Field can not be empty</p>');
   
           }
   
       })
   })
</script>
<?php } ?>