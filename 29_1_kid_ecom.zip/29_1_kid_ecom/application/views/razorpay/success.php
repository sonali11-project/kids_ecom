<?php  $admin_url = $this->config->item('admin_url'); ?> 
<div class="item active inner_pages">
  <img src="<?php echo base_url('assets/img/cart.jpg');?>" alt=" ">                      
  <div class="theme-container container">
    <div class="caption-text">
      <div class="cart_banner">
        <div class="inner_bg">
        <h3>Orders</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container">
	<div class="col-lg-12">
	    <h4 class="success">Thank you! Your payment was successful.</h4>
	    <table class="table table-responsive">
	    	<tr>
	    		<th>TransactionId</th>
	    		<th>Amount</th>
	    		<th>Total Item</th>
	    		<th>Status</th>
	    	</tr>
	    	<tr>
	    		<td><?php echo $itemInfo['transaction_id']?></td>
	    		<td><?php echo $itemInfo['cart_contents']['cart_total']?></td>
	    		<td><?php echo $itemInfo['cart_contents']['total_items']?></td>
	    		<td>success</td>
	    	</tr>
	    </table>
	</div>
	<div class="col-lg-12">
		<a href="<?= base_url() ?>Products/allProducts" class="btn btn-primary">Continue Shopping</a>
	</div>
</div>